ABRAHAM MUKITI NDILI — CYBERSECURITY PORTFOLIO
================================================

FILES
- index.html: website content
- style.css: visual design and responsive layout
- script.js: mobile navigation and current year

RUN IT IN TERMUX
1. Install Termux from a trusted source and open it.
2. Move/extract this website folder into your Termux home directory.
3. In Termux, enter the folder:
   cd abraham_mukiti_ndili_website
4. Start a local web server:
   python -m http.server 8000
5. Open Chrome and visit:
   http://127.0.0.1:8000

If Python is not installed:
   pkg update
   pkg install python

EDIT THE WEBSITE
Use a text editor such as nano:
   nano index.html
Save with Ctrl+O, Enter, then exit with Ctrl+X.
Keep index.html, style.css, and script.js in the same folder.

PUBLISH IT FOR FREE
You can upload these files to a GitHub repository and enable GitHub Pages
in the repository's Settings → Pages. Choose the branch and root folder.
The public website address will be shown by GitHub Pages after deployment.

CONTACT DETAILS INCLUDED
Phone: 0748 747 533
Email: abrahamndili586@gmail.com
Alternate email: abrahammndili@gmail.com
WhatsApp: https://wa.me/254748747533

The website is a static portfolio. It does not collect or store visitor data.
